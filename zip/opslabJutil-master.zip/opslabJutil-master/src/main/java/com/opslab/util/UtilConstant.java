package com.opslab.util;

/**
 * 定义一些工具类的常理
 */
public final class UtilConstant {
    public final static String APP_PACKAGE="com.opslab.util";
}
