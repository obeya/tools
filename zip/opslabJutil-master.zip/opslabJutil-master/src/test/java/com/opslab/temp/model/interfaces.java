package com.opslab.temp.model;

/**
 * Created by Administrator on 2016/4/20 0020.
 */
public interface interfaces {
}
