package com.opslab.util;


public class TestUtil {
   public static String path = System.getProperty("user.dir") + "/src/test/resource/";
}
